package com.construsales7;

import java.io.Serializable;

import jakarta.enterprise.inject.Model;

@Model
public class MessageBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4511535661678143808L;

	private String mensaje;

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}	
	
}
